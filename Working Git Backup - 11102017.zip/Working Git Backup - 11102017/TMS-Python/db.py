###############################################################
# TMS Database Connection File
###############################################################

import sqlite3
from sqlite3 import Error
import __main__
from pip._vendor.pkg_resources import null_ns_handler
 
import glob
import logging
import logging.handlers


LOG_FILENAME = '/home/pi/Documents/TMS-Git/TMS-Python/log/loggingRotatingFileExample.log'
'''
# Set up a specific logger with our desired output level
#LOG_FILENAME = 'example.log'
my_logger= logging.basicConfig(filename=LOG_FILENAME,level=logging.DEBUG)
#my_logger = logging.getLogger('MyLogger')
#my_logger.setLevel(logging.DEBUG)

# Add the log message handler to the logger
handler = logging.handlers.RotatingFileHandler(
              LOG_FILENAME, maxBytes=20, backupCount=1)

formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")

my_logger.setFormatter(formatter)

my_logger.addHandler(handler)



my_logger = logging.basicConfig(format='%(asctime)s :%(levelname)s: %(message)s',filename=LOG_FILENAME,level=logging.DEBUG)
my_logger = logging.getLogger('MyLogger')
'''


my_logger = logging.getLogger('myapp')
hdlr = logging.FileHandler(LOG_FILENAME)
formatter = logging.Formatter('%(asctime)s :%(levelname)s :%(message)s :')
hdlr.setFormatter(formatter)
my_logger.addHandler(hdlr) 
my_logger.setLevel(logging.DEBUG)


#def create database connection
def create_db_connection(db_file):
    """Create a database connection to the DB file .db"""
    
    try:
        conn = sqlite3.connect(db_file)
        my_logger.info(" Create a connection to DB ")
        return conn
    except Error as e:
        #print (e)
 
        my_logger.error(e)
        #raise
        
        return None


    

#Query DB Select Deveice detail by rfiduid
def select_DeviceDetails_by_rfiduid(conn, rfiduid1):
    """
    Query tasks by rfiduid
    param conn: the Connection object
    param rfiduid:
    """
    try:
        #print (" DB select_DeviceDetails_by_id")
        my_logger.info(" DB select_DeviceDetails_by_id")
        cur = conn.cursor()
        cur.execute("SELECT vehId, vehName, BUID, RFUID FROM DeviceDetails WHERE RFUID=?",(rfiduid1,))
 
        rows = cur.fetchall()
        vehDetails = None;
        for row in rows:
            if(row != None):
                vehDetails = row
                print vehDetails
        if (vehDetails != None):
            
            return vehDetails
        else:
            my_logger.warning("DB vehDetails not Avalable to the Tag ID :%s",rfiduid1)
            return None

    except Error as e:
        my_logger.error(e)

        return None

def select_TyreDetails_by_VehId(conn, VehId1):
    """
    Query tasks by priority
    param conn: the Connection object
    param rfiduid:
    """
    try:
        TyreDetials = []
        my_logger.info (" DB select_TireDetails_by_VehId ")
        cur = conn.cursor()
        cur.execute("SELECT sensorUID, tirePosition FROM TireDetails WHERE vehId=?",(VehId1,))
 
        rows = cur.fetchall()
        TyreDetails = None;
        for row in rows:
            TyreDetails = row
            #print TyreDetails
        
        #return TyreDetials
        return rows
    
    except Error as e:
        my_logger.error(e)

        return None


def main():
    
    database = "/opt/Aquire/sqlite/Sample.db"
    print (" DB Create a connection ")
    
    #create a connection to database
    conn = create_db_connection(database)

    tag = "e2000016351702081640767f"
    vehID = 32
    with conn:
        select_DeviceDetails_by_rfiduid(conn, tag)
        select_TyreDetails_by_VehId(conn, vehID)
        conn.close()

if __name__ == '__main__':
    main()
